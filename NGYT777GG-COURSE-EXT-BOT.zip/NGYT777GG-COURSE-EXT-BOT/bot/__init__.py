"""
Enhanced Telegram Bot Package
Course link finder with improved UI and progress tracking
"""

__version__ = "2.0.0"
__author__ = "Course Bot Team"
